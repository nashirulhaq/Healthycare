package com.dicoding.asclepius.data.preferences

import android.content.Context
import android.content.SharedPreferences

class UserPreference(context: Context) {
    companion object {
        private const val PREFS_NAME = "user_preferences"
        private const val KEY_NAME = "key_name"
    }

    private val preferences: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun saveName(name: String) {
        preferences.edit().putString(KEY_NAME, name).apply()
    }

    fun getName(): String? {
        return preferences.getString(KEY_NAME, null)
    }
}
