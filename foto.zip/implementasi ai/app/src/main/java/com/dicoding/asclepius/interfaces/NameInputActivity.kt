package com.dicoding.asclepius.interfaces

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.dicoding.asclepius.data.preferences.UserPreference
import com.dicoding.asclepius.databinding.ActivityNameInputBinding

class NameInputActivity : AppCompatActivity() {
    private lateinit var binding: ActivityNameInputBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val userPreference = UserPreference(this)
        val savedName = userPreference.getName()

        if (!savedName.isNullOrEmpty()) {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
            return
        }

        binding = ActivityNameInputBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSave.setOnClickListener {
            val name = binding.edName.text.toString()

            if (name.isNotBlank()) {
                userPreference.saveName(name)

                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                binding.edName.error = "Name cannot be empty"
            }
        }
    }
}
