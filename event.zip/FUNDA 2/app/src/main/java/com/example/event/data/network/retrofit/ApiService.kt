package com.example.event.data.network.retrofit

import com.example.event.data.network.response.DetailResponse
import com.example.event.data.network.response.EventResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("events")
    fun getEvent(
        @Query("active") active: Int = 1
    ): Call<EventResponse>

    @GET("events/{id}")
    fun getDetailEvent(
        @Path("id") id: Int?
    ): Call<DetailResponse>
}