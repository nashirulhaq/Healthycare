package com.example.event

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.asLiveData
import com.example.event.data.local.AppDatabase
import com.example.event.data.local.DatabaseBuilder
import com.example.event.data.local.preference.SettingPreferences
import com.example.event.data.local.preference.dataStore

class MyApplication : Application() {

    private lateinit var database: AppDatabase
    lateinit var settingPreferences: SettingPreferences

    override fun onCreate() {
        super.onCreate()

        database = DatabaseBuilder.getInstance(this)

        settingPreferences = SettingPreferences.getInstance(applicationContext.dataStore)

        observeThemeSettings()
    }

    private fun observeThemeSettings() {
        val dataStore = settingPreferences.getThemeSetting()
        dataStore.asLiveData().observeForever { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }
    }
}
