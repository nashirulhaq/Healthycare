package com.example.event.data.local.repository

import androidx.lifecycle.LiveData
import com.example.event.data.local.entity.Favorite
import com.example.event.data.local.entity.FavoriteDao
import com.example.event.data.network.response.Event
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class FavoriteRepository(private val favoriteDao: FavoriteDao) {

    suspend fun addEventToFavorites(event: Event) {
        val favorite = Favorite(
            id = event.id ?: 0,
            summary = event.summary,
            mediaCover = event.mediaCover,
            registrants = event.registrants,
            imageLogo = event.imageLogo,
            link = event.link,
            description = event.description,
            ownerName = event.ownerName,
            cityName = event.cityName,
            quota = event.quota,
            name = event.name,
            beginTime = event.beginTime,
            endTime = event.endTime,
            category = event.category
        )
        withContext(Dispatchers.IO) {
            favoriteDao.insertFavorite(favorite)
        }
    }

    fun getFavorites(): LiveData<List<Favorite>> {
        return favoriteDao.getAllFavorites()
    }

    suspend fun deleteFavoriteById(id: Int) {
        favoriteDao.deleteFavorite(id)
    }
}