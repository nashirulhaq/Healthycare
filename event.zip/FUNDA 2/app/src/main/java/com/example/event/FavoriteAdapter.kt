package com.example.event

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.event.data.local.entity.Favorite
import com.example.event.databinding.ItemEventBinding

class FavoriteAdapter(
    private val favorites: List<Favorite>,
    private val onItemClick: (Favorite) -> Unit
) : RecyclerView.Adapter<FavoriteAdapter.FavoriteViewHolder>() {

    inner class FavoriteViewHolder(private val binding: ItemEventBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(favorite: Favorite) {
            binding.tvEventTopics.text = favorite.name
            binding.tvEventOrganizer.text = favorite.ownerName
            Glide
                .with(binding.imgEvent.context)
                .load(favorite.imageLogo)
                .centerCrop()
                .into(binding.imgEvent)

            binding.root.setOnClickListener {
                onItemClick(favorite)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteViewHolder {
        val binding = ItemEventBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FavoriteViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FavoriteViewHolder, position: Int) {
        holder.bind(favorites[position])
    }

    override fun getItemCount(): Int = favorites.size
}
