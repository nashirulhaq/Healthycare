package com.example.event.viewmodel

import androidx.lifecycle.ViewModel

class HomeViewModel: ViewModel() {
}