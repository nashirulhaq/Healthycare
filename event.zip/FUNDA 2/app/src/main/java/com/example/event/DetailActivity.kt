package com.example.event

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Html
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.example.event.data.local.DatabaseBuilder
import com.example.event.data.local.preference.SettingPreferences
import com.example.event.data.local.preference.dataStore
import com.example.event.data.local.repository.FavoriteRepository
import com.example.event.data.network.response.Event
import com.example.event.databinding.ActivityDetailBinding
import com.example.event.viewmodel.DetailViewModel
import com.example.event.viewmodel.FavoriteViewModel
import com.example.event.viewmodel.ViewModelFactory

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    private lateinit var detailViewModel: DetailViewModel
    private lateinit var favoriteViewModel: FavoriteViewModel
    private var isFavorite: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val pref = SettingPreferences.getInstance(applicationContext.dataStore)
        detailViewModel = ViewModelProvider(this)[DetailViewModel::class.java]
        favoriteViewModel = ViewModelProvider(
            this,
            ViewModelFactory(
                FavoriteRepository(DatabaseBuilder.getInstance(this).favoriteDao()),
                pref
            )
        )[FavoriteViewModel::class.java]

        val eventId = intent.getIntExtra("EVENT_ID", 0)
        detailViewModel.getDetail(eventId)

        detailViewModel.detailData.observe(this) { event ->
            event?.event?.let { eventDetails ->
                updateUI(eventDetails)

                checkIfFavorite(eventDetails.id)

                binding.fabFavorite.setOnClickListener {
                    toggleFavorite(eventDetails)
                }
            }
        }

        detailViewModel.isLoading.observe(this) { isLoading ->
            showLoading(isLoading)
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updateUI(event: Event) {
        binding.tvTitle.text = event.name
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            binding.tvDescription.text = Html.fromHtml(event.description ?: "", Html.FROM_HTML_MODE_LEGACY)
        }
        binding.tvCity.text = event.cityName
        binding.tvQuota.text = ((event.quota ?: 0) - (event.registrants ?: 0)).toString()
        binding.tvBeginTime.text = event.beginTime
        binding.tvOwnerName.text = event.ownerName

        Glide.with(binding.root)
            .load(event.imageLogo)
            .into(binding.ivEvent)

        binding.btnLink.setOnClickListener {
            val url = event.link
            if (!url.isNullOrEmpty()) {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                startActivity(intent)
            }
        }
    }

    private fun checkIfFavorite(eventId: Int?) {
        if (eventId == null) return

        favoriteViewModel.getFavorites { favorites ->
            isFavorite = favorites.any { it.id == eventId }
            updateFavoriteIcon()
        }
    }

    private fun toggleFavorite(event: Event) {
        if (isFavorite) {
            favoriteViewModel.deleteFavorite(event.id ?: return)
            isFavorite = false
            Toast.makeText(this, "Removed from favorites", Toast.LENGTH_SHORT).show()
        } else {
            favoriteViewModel.setFavorite(event)
            isFavorite = true
            Toast.makeText(this, "Added to favorites", Toast.LENGTH_SHORT).show()
        }
        updateFavoriteIcon()
    }

    private fun updateFavoriteIcon() {
        val icon = if (isFavorite) R.drawable.baseline_favorite_24 else R.drawable.baseline_favorite_border_24
        binding.fabFavorite.setImageResource(icon)
    }

    private fun showLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        binding.layoutData.visibility = if (loading) View.GONE else View.VISIBLE
    }
}

