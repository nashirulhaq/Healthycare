package com.example.event.fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.event.DetailActivity
import com.example.event.FavoriteAdapter
import com.example.event.data.local.DatabaseBuilder
import com.example.event.data.local.preference.SettingPreferences
import com.example.event.data.local.preference.dataStore
import com.example.event.data.local.repository.FavoriteRepository
import com.example.event.databinding.FragmentFavoriteBinding
import com.example.event.viewmodel.FavoriteViewModel
import com.example.event.viewmodel.ViewModelFactory

class FavoriteFragment : Fragment() {
    private var _binding: FragmentFavoriteBinding? = null
    private val binding get() = _binding!!

    private lateinit var favoriteViewModel: FavoriteViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentFavoriteBinding.inflate(inflater, container, false)
        val root: View = binding.root
        val pref = SettingPreferences.getInstance(requireContext().applicationContext.dataStore)
        favoriteViewModel = ViewModelProvider(
            this,
            ViewModelFactory(
                FavoriteRepository(DatabaseBuilder.getInstance(requireContext()).favoriteDao()),
                pref
            )
        )[FavoriteViewModel::class.java]

        setupRecyclerView()
        observeFavorites()

        return root
    }

    private fun setupRecyclerView() {
        binding.rvFavoriteEvent.layoutManager = LinearLayoutManager(requireContext())
    }

    private fun observeFavorites() {
        favoriteViewModel.getFavorites { favorites ->
            Log.d("FavoritesCallback", "Fetched favorites: ${favorites.size}")
        }
        favoriteViewModel.favoriteData.observe(viewLifecycleOwner) { favorites ->
            binding.rvFavoriteEvent.adapter = FavoriteAdapter(favorites) { favorite ->
                val intent = Intent(requireContext(), DetailActivity::class.java)
                intent.putExtra("EVENT_ID", favorite.id)
                startActivity(intent)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
