package com.example.event.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.event.data.local.preference.SettingPreferences
import com.example.event.data.local.repository.FavoriteRepository

class ViewModelFactory(private val repository: FavoriteRepository, private val pref: SettingPreferences) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FavoriteViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return FavoriteViewModel(repository) as T
        }
        if (modelClass.isAssignableFrom(SettingViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SettingViewModel(pref) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}