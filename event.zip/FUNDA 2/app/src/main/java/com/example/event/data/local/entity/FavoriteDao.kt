package com.example.event.data.local.entity

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface FavoriteDao {
    @Insert
    suspend fun insertFavorite(favorite: Favorite)

    @Query("SELECT * FROM favorite_events")
    fun getAllFavorites(): LiveData<List<Favorite>>

    @Query("DELETE FROM favorite_events WHERE id = :id")
    suspend fun deleteFavorite(id: Int)
}