package com.example.event.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.event.data.local.entity.Favorite
import com.example.event.data.local.repository.FavoriteRepository
import com.example.event.data.network.response.Event
import kotlinx.coroutines.launch

class FavoriteViewModel(private val favoriteRepository: FavoriteRepository): ViewModel() {
    val favoriteData: LiveData<List<Favorite>> = favoriteRepository.getFavorites()

    fun setFavorite(event: Event){
        viewModelScope.launch {
            favoriteRepository.addEventToFavorites(event)
        }
    }
    
    fun getFavorites(callback: (List<Favorite>) -> Unit) {
        favoriteData.observeForever { favorites ->
            callback(favorites)
        }
    }

    fun deleteFavorite(id: Int) {
        viewModelScope.launch {
            favoriteRepository.deleteFavoriteById(id)
        }
    }
}